use serde::Deserialize;
//use std::env;
//use std::fs;
use std::fs::File;
use std::io::BufRead;
use std::io::{BufReader, BufWriter, Write};
//use std::path::Path;

#[derive(Deserialize, Debug)]
struct FourLetterWords {
  word: String,
  score: u64,
  tags: Vec<String>,
}

/*
fn read_lines<P>(filename: P) -> io::Result<io::Lines<io::BufReader<File>>>
where
  P: AsRef<Path>,
{
  let file = File::open(filename)?;
  Ok(io::BufReader::new(file).lines())
}
*/

fn get_response(url: String) -> bool {
  println!("{}", url);
  let res: reqwest::Result<reqwest::blocking::Response> = reqwest::blocking::get(url);
  let resp = res.unwrap().json::<Vec<FourLetterWords>>().unwrap();
  //println!("{:#?}", resp[0].tags);
  let needle = "f:".to_string();
  let haystack = &resp[0].tags;

  if let Some(word) = haystack.into_iter().find(|&s| s.starts_with(&needle)) {
    let score = &word[2..];
    let numeric_score: f64 = score.parse().unwrap();
    if numeric_score > 0.7 {
      //println!("{}", &resp[0].word.to_uppercase());
      return true;
    }
  }

  return false;
}

fn main() {
  let file = File::open("resources/4-letter-words-processed.txt").unwrap();
  let reader = BufReader::new(file);
  let newfile = File::create("resources/4-letter-words-processed-new.txt").unwrap();
  let mut writer = BufWriter::new(newfile);
  for lineresult in reader.lines() {
    let line = lineresult.unwrap();
    if get_response(format!(
      "https://api.datamuse.com/words?sp={}&qe=sp&md=f&max=1",
      line
    )) {
      println!("{}", line);
      writeln!(&mut writer, "{}", line);
    }
  }
}
